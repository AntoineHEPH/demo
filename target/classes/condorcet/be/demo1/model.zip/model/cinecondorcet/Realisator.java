package condorcet.be.demo1.model.cinecondorcet;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "REALISATOR")
public class Realisator {

    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String surname;

    @OneToMany(mappedBy = "realisator", cascade = CascadeType.ALL)
    private List<Film> films = new ArrayList<>();

    public Realisator(String christopher, String nolan, LocalDate localDate) {}

    public Realisator() {}

    public Realisator(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }

    public void addFilm(Film film) {
        this.films.add(film);
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public List getFilms() {
        return films;
    }


}
