package condorcet.be.demo1.model;

import java.util.List;

public record Character(String name, String role, List<String> skills) {

}
