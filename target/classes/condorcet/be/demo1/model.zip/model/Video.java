package condorcet.be.demo1.model;

public record Video(String title, String description, String url) {}