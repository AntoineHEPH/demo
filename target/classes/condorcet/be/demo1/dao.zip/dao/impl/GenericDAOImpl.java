package condorcet.be.demo1.dao.impl;

import condorcet.be.demo1.dao.GenericDAO;
import condorcet.be.demo1.model.cinecondorcet.Film;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.util.List;

public class GenericDAOImpl<T, ID> implements GenericDAO<T, ID> {
    protected EntityManager em;
    private Class<T> entityClass;

    // Constructeur pour injecter l'EntityManager
    public GenericDAOImpl(EntityManager em, Class<T> entityClass) {
        this.em = em;
        this.entityClass = entityClass;
    }

    @Override
    public void create(T entity) {
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
    }

    @Override
    public void update(T entity) {
        em.getTransaction().begin();
        em.merge(entity);
        em.getTransaction().commit();

    }

    @Override
    public void delete(T entity) {
        em.getTransaction().begin();
        em.remove(entity);
        em.getTransaction().commit();

    }

    @Override
    public T findById(ID id) {
        String jpql = "SELECT e FROM " + entityClass.getSimpleName() + " e WHERE e.id = :id";
        TypedQuery<T> query = em.createQuery(jpql, entityClass);
        query.setParameter("id", id);
        return query.getSingleResult();
    }

    @Override
    public List<T> findAll() {
        String jpql = "SELECT x FROM "+entityClass.getSimpleName()+" x";
        TypedQuery<T> query = em.createQuery(jpql, entityClass);
        return query.getResultList();
    }
}
