package condorcet.be.demo1.dao.impl;

import condorcet.be.demo1.dao.RealisatorDAO;
import condorcet.be.demo1.model.cinecondorcet.Realisator;
import jakarta.persistence.EntityManager;

public class RealisatorDAOImpl extends GenericDAOImpl<Realisator, Long> implements RealisatorDAO {
    public RealisatorDAOImpl(EntityManager em) {
        super(em, Realisator.class);
    }
}
